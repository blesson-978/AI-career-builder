
function suggestCareer() {
  const input = document.getElementById("skillsInput").value.toLowerCase();
  const output = document.getElementById("output");
  let suggestion = "";

  if (input.includes("html") && input.includes("css") && input.includes("js")) {
    suggestion = "You can become a Frontend Web Developer!";
  } else if (input.includes("java") || input.includes("kotlin")) {
    suggestion = "You can become an Android App Developer!";
  } else if (input.includes("python") || input.includes("ai")) {
    suggestion = "You can become an AI/ML Engineer!";
  } else {
    suggestion = "Try learning more tech skills to unlock more career paths.";
  }

  output.textContent = suggestion;
}
